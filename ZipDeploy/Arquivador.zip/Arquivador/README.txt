READ ME


ARGUMENTOS

-l :	Ativa o Log
-w :	(wait Key Press) Aguarda uma tecla ser pressionada apos a instrucao
-? : 	(Write Help) Escreve po menu de ajuda na tela.

LOG FORMAT

Log_yyyy-MM-dd_hhmmss.txt